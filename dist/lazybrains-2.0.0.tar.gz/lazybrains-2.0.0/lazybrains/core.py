import argparse
import time
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import shap
from pathlib import Path

# --- Scikit-learn Imports ---
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, f1_score, roc_curve, auc, RocCurveDisplay,
                             ConfusionMatrixDisplay, r2_score, mean_squared_error)
from sklearn.feature_selection import SelectKBest, f_classif, f_regression
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest

# --- Model Imports ---
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge, Lasso
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import (RandomForestClassifier, RandomForestRegressor, StackingClassifier, StackingRegressor,
                              GradientBoostingClassifier, GradientBoostingRegressor, AdaBoostClassifier, AdaBoostRegressor)
from xgboost import XGBClassifier, XGBRegressor
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.svm import SVC, SVR
from sklearn.naive_bayes import GaussianNB

# --- Parallel Processing ---
from joblib import Parallel, delayed

# --- Rich CLI Library ---
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn
from rich.syntax import Syntax

# Ignore common warnings for a cleaner output
warnings.filterwarnings('ignore')

# Initialize Rich Console
console = Console()

# --- Core Functions ---

def detect_problem_type(target_series: pd.Series) -> str:
    """
    Automatically detects if the problem is classification or regression.
    """
    if target_series.dtype in ['object', 'category', 'bool']:
        return 'classification'

    unique_values = target_series.nunique()
    if unique_values < 2:
         raise ValueError("Target column has less than 2 unique values. Cannot perform modeling.")
    # Heuristic: If low cardinality integer feature, treat as classification
    if pd.api.types.is_integer_dtype(target_series) and unique_values < 50 and (unique_values / len(target_series)) < 0.05:
        return 'classification'

    return 'regression'

def get_models(problem_type: str) -> dict:
    """Returns a dictionary of diverse models suitable for the problem type."""
    n_jobs = -1  # Use all available cores for models that support it
    random_state = 42

    if problem_type == 'classification':
        # Base estimators for Stacking
        estimators_clf = [
            ('rf', RandomForestClassifier(random_state=random_state, n_jobs=n_jobs)),
            ('gb', GradientBoostingClassifier(random_state=random_state))
        ]
        models = {
            "Logistic Regression": LogisticRegression(random_state=random_state, n_jobs=n_jobs, max_iter=1000),
            "Decision Tree": DecisionTreeClassifier(random_state=random_state),
            "Random Forest": RandomForestClassifier(random_state=random_state, n_jobs=n_jobs),
            "Gradient Boosting": GradientBoostingClassifier(random_state=random_state),
            "AdaBoost": AdaBoostClassifier(random_state=random_state),
            "Support Vector Machine": SVC(random_state=random_state, probability=True),
            "K-Nearest Neighbors": KNeighborsClassifier(n_jobs=n_jobs),
            "XGBoost": XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=random_state, n_jobs=n_jobs),
            "Stacking": StackingClassifier(estimators=estimators_clf, final_estimator=LogisticRegression(), n_jobs=n_jobs)
        }
    else:  # regression
        # Base estimators for Stacking
        estimators_reg = [
            ('rf', RandomForestRegressor(random_state=random_state, n_jobs=n_jobs)),
            ('ridge', Ridge(random_state=random_state))
        ]
        models = {
            "Linear Regression": LinearRegression(n_jobs=n_jobs),
            "Ridge": Ridge(random_state=random_state),
            "Lasso": Lasso(random_state=random_state),
            "Decision Tree": DecisionTreeRegressor(random_state=random_state),
            "Random Forest": RandomForestRegressor(random_state=random_state, n_jobs=n_jobs),
            "Gradient Boosting": GradientBoostingRegressor(random_state=random_state),
            "Support Vector Machine": SVR(),
            "K-Nearest Neighbors": KNeighborsRegressor(n_jobs=n_jobs),
            "XGBoost": XGBRegressor(random_state=random_state, n_jobs=n_jobs),
            "Stacking": StackingRegressor(estimators=estimators_reg, final_estimator=Ridge(), n_jobs=n_jobs)
        }
    return models

# -*- coding: utf-8 -*-
"""
AutoFeatSelect: A Lightweight Python Library for Automatic Feature Selection.

This library provides a single class, AutoFeatSelect, to automatically identify and
drop irrelevant, redundant, or low-information features from a pandas DataFrame.
It uses a combination of statistical, mathematical, and model-based techniques
to clean a dataset, making it ready for machine learning.

Core Features:
- Handles both numerical and categorical data.
- Provides a detailed report explaining why each feature was dropped.
- Highly customizable with thresholds for various checks.
- Lightweight, with dependencies only on pandas, numpy, scikit-learn, and statsmodels.

Author: Gemini
Version: 1.0.0
"""

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_selection import VarianceThreshold, mutual_info_classif, mutual_info_regression
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
from sklearn.preprocessing import LabelEncoder
from statsmodels.stats.outliers_influence import variance_inflation_factor
from scipy.cluster import hierarchy
from scipy.spatial.distance import squareform
import warnings

warnings.filterwarnings('ignore', category=FutureWarning)

class AutoFeatSelect(BaseEstimator, TransformerMixin):
    """
    Automated feature selection tool to drop irrelevant or redundant features.

    This transformer applies a series of selection methods in a specific order
    to efficiently prune the feature space.

    Parameters
    ----------
    target_col : str, optional (default=None)
        Name of the target column. If provided, it will be used for supervised
        selection methods.
    
    missing_threshold : float, optional (default=0.95)
        Drop columns with a ratio of missing values higher than this threshold.
        
    id_threshold : float, optional (default=0.99)
        Drop columns where the ratio of unique values to rows is higher than this.
        Useful for dropping ID-like columns.
        
    variance_threshold : float, optional (default=0.01)
        Threshold for the VarianceThreshold selector to drop low-variance features.
        
    correlation_threshold : float, optional (default=0.90)
        Drop one of a pair of features with a Pearson correlation higher than this.
        
    use_correlation_clustering : bool, optional (default=True)
        If True, uses hierarchical clustering on the correlation matrix to drop
        redundant features, which can be more robust than pairwise checks. If False,
        uses a simpler pairwise correlation check.

    multicollinearity_threshold : float, optional (default=10.0)
        Variance Inflation Factor (VIF) threshold for dropping collinear features.
        
    feature_importance_threshold : float, optional (default=0.001)
        Threshold for tree-based feature importance. Features with importance
        below this will be dropped. Requires a target column.
        
    mutual_info_threshold : float, optional (default=0.01)
        Threshold for mutual information. Features with MI below this will be dropped.
        Requires a target column.
        
    verbose : bool, optional (default=False)
        If True, prints progress during the fitting process.
    """

    def __init__(self, target_col=None, missing_threshold=0.95, id_threshold=0.99,
                 variance_threshold=0.01, correlation_threshold=0.90,
                 use_correlation_clustering=True, multicollinearity_threshold=10.0,
                 feature_importance_threshold=0.001, mutual_info_threshold=0.01,
                 verbose=False):
        self.target_col = target_col
        self.missing_threshold = missing_threshold
        self.id_threshold = id_threshold
        self.variance_threshold = variance_threshold
        self.correlation_threshold = correlation_threshold
        self.use_correlation_clustering = use_correlation_clustering
        self.multicollinearity_threshold = multicollinearity_threshold
        self.feature_importance_threshold = feature_importance_threshold
        self.mutual_info_threshold = mutual_info_threshold
        self.verbose = verbose
        
        self.dropped_features_report_ = {}
        self.initial_features_ = []
        self.final_features_ = []

    def _log(self, message):
        """Prints a message if verbose is True."""
        if self.verbose:
            print(f"[AutoFeatSelect] {message}")

    def _add_to_report(self, features, reason):
        """Adds dropped features and the reason to the report."""
        if not isinstance(features, list):
            features = [features]
        for feature in features:
            if feature not in self.dropped_features_report_:
                self.dropped_features_report_[feature] = reason

    def fit(self, X, y=None):
        """
        Fits the feature selector to the data.

        Parameters
        ----------
        X : pd.DataFrame
            The input data.
        y : pd.Series or np.array, optional (default=None)
            The target variable. If not provided, the `target_col` in X will be used.
        
        Returns
        -------
        self : object
            Returns the instance itself.
        """
        if not isinstance(X, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame.")

        df = X.copy()
        
        # Separate target if it exists
        if self.target_col and self.target_col in df.columns:
            y = df[self.target_col]
            df = df.drop(columns=[self.target_col])
            self._log(f"Target column '{self.target_col}' identified and separated.")

        self.initial_features_ = df.columns.tolist()
        
        # --- Stage 1: Basic Cleanup (Unsupervised) ---
        df = self._drop_missing_values(df)
        df = self._drop_single_value_columns(df)
        df = self._drop_id_like_columns(df)
        
        # --- Stage 2: Statistical Pruning (Unsupervised) ---
        df = self._drop_low_variance_features(df)
        if self.use_correlation_clustering:
            df = self._drop_correlated_features_clustered(df)
        else:
            df = self._drop_correlated_features_pairwise(df)
        df = self._drop_multicollinearity(df)

        # --- Stage 3: Supervised Selection (if target is available) ---
        if y is not None:
            self._log("Target variable provided. Running supervised selection methods.")
            # Ensure y is a pandas Series with the same index as df
            y = pd.Series(y, index=df.index)
            
            # Impute NaNs for supervised methods
            df_imputed, y_imputed = self._impute_for_supervised(df, y)
            
            df = self._drop_low_mutual_information(df_imputed, y_imputed)
            df = self._drop_low_importance_features(df_imputed, y_imputed)
        else:
            self._log("No target variable. Skipping supervised selection methods.")
            
        self.final_features_ = df.columns.tolist()
        self._log(f"Finished selection. Kept {len(self.final_features_)} out of {len(self.initial_features_)} features.")
        return self

    def transform(self, X, drop=True):
        """
        Transforms the data by dropping selected features.

        Parameters
        ----------
        X : pd.DataFrame
            The input data to transform.
        drop : bool, optional (default=True)
            If True, drops the identified features. If False, returns the original DataFrame.

        Returns
        -------
        pd.DataFrame
            The transformed DataFrame with irrelevant features removed.
        """
        if not drop:
            return X
        
        if not self.final_features_:
             raise RuntimeError("You must call 'fit' before calling 'transform'.")
        
        df = X.copy()
        
        # Ensure target column is preserved if it was in the original transform input
        cols_to_keep = self.final_features_
        if self.target_col and self.target_col in df.columns:
            cols_to_keep = [self.target_col] + self.final_features_
            
        return df[cols_to_keep]

    def fit_transform(self, X, y=None, drop=True):
        """
        Fits to data, then transforms it.

        Parameters
        ----------
        X : pd.DataFrame
            The input data.
        y : pd.Series or np.array, optional (default=None)
            The target variable.
        drop : bool, optional (default=True)
            If True, drops the identified features. If False, returns the original DataFrame.

        Returns
        -------
        pd.DataFrame
            The transformed DataFrame.
        """
        self.fit(X, y)
        return self.transform(X, drop=drop)
    
    def get_report(self, as_dataframe=True):
        """
        Returns a report of dropped features and the reasons.

        Parameters
        ----------
        as_dataframe : bool, optional (default=True)
            If True, returns the report as a pandas DataFrame. Otherwise, returns a dict.

        Returns
        -------
        pd.DataFrame or dict
            A report detailing which features were dropped and why.
        """
        if not self.dropped_features_report_:
            print("No features were dropped.")
            return pd.DataFrame(columns=['Feature', 'Reason Dropped']) if as_dataframe else {}
            
        if as_dataframe:
            report_df = pd.DataFrame(list(self.dropped_features_report_.items()),
                                     columns=['Feature', 'Reason Dropped'])
            report_df.sort_values(by='Reason Dropped', inplace=True)
            return report_df
        return self.dropped_features_report_

    # --- Private Helper Methods for each selection stage ---

    def _drop_missing_values(self, df):
        self._log("Running: Drop high missing values...")
        missing_ratio = df.isnull().sum() / len(df)
        high_missing_cols = missing_ratio[missing_ratio > self.missing_threshold].index.tolist()
        if high_missing_cols:
            self._add_to_report(high_missing_cols, f"Missing > {self.missing_threshold*100:.0f}%")
            df = df.drop(columns=high_missing_cols)
            self._log(f"  Dropped: {high_missing_cols}")
        return df

    def _drop_single_value_columns(self, df):
        self._log("Running: Drop single value columns...")
        single_value_cols = [col for col in df.columns if df[col].nunique(dropna=False) <= 1]
        if single_value_cols:
            self._add_to_report(single_value_cols, "Single unique value")
            df = df.drop(columns=single_value_cols)
            self._log(f"  Dropped: {single_value_cols}")
        return df

    def _drop_id_like_columns(self, df):
        self._log("Running: Drop ID-like columns...")
        id_cols = []
        for col in df.columns:
            # Check for high cardinality primarily in object/int columns
            if df[col].dtype in ['object', 'int64']:
                unique_ratio = df[col].nunique() / len(df)
                if unique_ratio > self.id_threshold:
                    id_cols.append(col)
        
        if id_cols:
            self._add_to_report(id_cols, f"ID-like (unique > {self.id_threshold*100:.0f}%)")
            df = df.drop(columns=id_cols)
            self._log(f"  Dropped: {id_cols}")
        return df

    def _drop_low_variance_features(self, df):
        self._log("Running: Drop low variance features...")
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        if not numeric_cols:
            return df
        
        temp_df = df[numeric_cols].dropna() # VarianceThreshold can't handle NaNs
        if temp_df.empty:
            return df

        selector = VarianceThreshold(threshold=self.variance_threshold)
        selector.fit(temp_df)
        
        low_variance_cols = [col for col, var in zip(temp_df.columns, selector.variances_) if var < self.variance_threshold]
        
        if low_variance_cols:
            self._add_to_report(low_variance_cols, f"Variance < {self.variance_threshold}")
            df = df.drop(columns=low_variance_cols)
            self._log(f"  Dropped: {low_variance_cols}")
        return df

    def _drop_correlated_features_pairwise(self, df):
        self._log("Running: Drop highly correlated features (pairwise)...")
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        if len(numeric_cols) < 2:
            return df

        corr_matrix = df[numeric_cols].corr().abs()
        upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        
        to_drop = [column for column in upper.columns if any(upper[column] > self.correlation_threshold)]
        
        if to_drop:
            self._add_to_report(to_drop, f"High correlation > {self.correlation_threshold}")
            df = df.drop(columns=to_drop)
            self._log(f"  Dropped: {to_drop}")
        return df

    def _drop_correlated_features_clustered(self, df):
        self._log("Running: Drop highly correlated features (hierarchical clustering)...")
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        if len(numeric_cols) < 2:
            return df

        corr = df[numeric_cols].corr().abs()
        dist = squareform(1 - corr)
        linkage_matrix = hierarchy.linkage(dist, method='average')
        
        clusters = hierarchy.fcluster(linkage_matrix, 1 - self.correlation_threshold, criterion='distance')
        
        cluster_map = pd.DataFrame({'feature': numeric_cols, 'cluster': clusters})
        
        to_drop = []
        for cluster_id in cluster_map['cluster'].unique():
            features_in_cluster = cluster_map[cluster_map['cluster'] == cluster_id]['feature'].tolist()
            if len(features_in_cluster) > 1:
                # Keep the first feature, drop the rest in the cluster
                to_drop.extend(features_in_cluster[1:])
        
        if to_drop:
            self._add_to_report(to_drop, f"Redundant (correlation cluster > {self.correlation_threshold})")
            df = df.drop(columns=to_drop)
            self._log(f"  Dropped: {to_drop}")
        return df

    def _drop_multicollinearity(self, df):
        self._log("Running: Drop multicollinear features (VIF)...")
        numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
        if len(numeric_cols) < 2:
            return df
            
        X_numeric = df[numeric_cols].dropna()
        if X_numeric.empty:
            return df

        # Iteratively drop features with high VIF
        while True:
            vif = pd.DataFrame()
            vif["feature"] = X_numeric.columns
            vif["VIF"] = [variance_inflation_factor(X_numeric.values, i) for i in range(X_numeric.shape[1])]
            
            max_vif = vif['VIF'].max()
            if max_vif > self.multicollinearity_threshold:
                feature_to_drop = vif.sort_values('VIF', ascending=False)['feature'].iloc[0]
                self._add_to_report(feature_to_drop, f"High multicollinearity (VIF > {self.multicollinearity_threshold})")
                X_numeric = X_numeric.drop(columns=[feature_to_drop])
                self._log(f"  Dropped: {feature_to_drop} (VIF: {max_vif:.2f})")
            else:
                break
        
        final_numeric_cols = X_numeric.columns.tolist()
        cols_to_drop_from_df = [col for col in numeric_cols if col not in final_numeric_cols]
        df = df.drop(columns=cols_to_drop_from_df)
        return df

    def _impute_for_supervised(self, df, y):
        """A simple imputer for supervised methods."""
        df_imputed = df.copy()
        y_imputed = y.copy()

        # Impute y if it has missing values
        if y_imputed.isnull().any():
            if pd.api.types.is_numeric_dtype(y_imputed):
                y_imputed.fillna(y_imputed.median(), inplace=True)
            else:
                y_imputed.fillna(y_imputed.mode()[0], inplace=True)

        for col in df_imputed.columns:
            if df_imputed[col].isnull().any():
                if pd.api.types.is_numeric_dtype(df_imputed[col]):
                    df_imputed[col].fillna(df_imputed[col].median(), inplace=True)
                else:
                    df_imputed[col].fillna(df_imputed[col].mode()[0], inplace=True)
        return df_imputed, y_imputed


    def _drop_low_mutual_information(self, df, y):
        self._log("Running: Drop features with low mutual information...")
        df_encoded = df.copy()
        
        # Label encode categorical features for MI calculation
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        for col in categorical_cols:
            le = LabelEncoder()
            df_encoded[col] = le.fit_transform(df_encoded[col])
            
        if pd.api.types.is_numeric_dtype(y):
            mi_scores = mutual_info_regression(df_encoded, y)
        else:
            mi_scores = mutual_info_classif(df_encoded, y)
            
        mi_series = pd.Series(mi_scores, index=df_encoded.columns)
        low_mi_features = mi_series[mi_series < self.mutual_info_threshold].index.tolist()
        
        if low_mi_features:
            self._add_to_report(low_mi_features, f"Mutual Information < {self.mutual_info_threshold}")
            df = df.drop(columns=low_mi_features)
            self._log(f"  Dropped: {low_mi_features}")
        return df

    def _drop_low_importance_features(self, df, y):
        self._log("Running: Drop low importance features (Tree-based)...")
        df_encoded = df.copy()
        
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        for col in categorical_cols:
            le = LabelEncoder()
            df_encoded[col] = le.fit_transform(df_encoded[col])
            
        if pd.api.types.is_numeric_dtype(y):
            model = ExtraTreesRegressor(n_estimators=50, random_state=42, n_jobs=-1)
        else:
            model = ExtraTreesClassifier(n_estimators=50, random_state=42, n_jobs=-1)
            
        model.fit(df_encoded, y)
        
        importances = pd.Series(model.feature_importances_, index=df_encoded.columns)
        low_importance_features = importances[importances < self.feature_importance_threshold].index.tolist()
        
        if low_importance_features:
            self._add_to_report(low_importance_features, f"Feature Importance < {self.feature_importance_threshold}")
            df = df.drop(columns=low_importance_features)
            self._log(f"  Dropped: {low_importance_features}")
        return df


def build_preprocessor(X: pd.DataFrame, problem_type: str, n_features: int = None, pca_components: int = None) -> ColumnTransformer:
    """Builds a scikit-learn ColumnTransformer for preprocessing."""
    numeric_features = X.select_dtypes(include=np.number).columns.tolist()
    categorical_features = X.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()

    # Define pipelines for numeric and categorical features
    numeric_transformer_steps = [
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ]
    if pca_components and pca_components > 0:
        numeric_transformer_steps.append(('pca', PCA(n_components=pca_components)))
        console.print(f"🔩 [cyan]Applying PCA with {pca_components} components.[/cyan]")

    numeric_transformer = Pipeline(steps=numeric_transformer_steps)

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])

    # Create the main preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('cat', categorical_transformer, categorical_features)
        ],
        remainder='passthrough',
        n_jobs=-1 # Parallelize the transformation
    )
    return preprocessor

def train_and_evaluate_model(name, model, preprocessor, X_train, y_train, X_test, y_test, problem_type):
    """A helper function to train one model, used for parallel execution."""
    start_time = time.time()

    # Create the full pipeline
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('model', model)
    ])

    # Train model
    pipeline.fit(X_train, y_train)

    # Evaluate model
    y_pred = pipeline.predict(X_test)

    metric1, metric2 = (0, 0)
    if problem_type == 'classification':
        metric1 = accuracy_score(y_test, y_pred)
        metric2 = f1_score(y_test, y_pred, average='weighted')
    else: # regression
        metric1 = r2_score(y_test, y_pred)
        metric2 = np.sqrt(mean_squared_error(y_test, y_pred))

    elapsed_time = time.time() - start_time

    return {
        "Model": name,
        "Metric1": metric1,
        "Metric2": metric2,
        "Time (s)": elapsed_time,
        "pipeline": pipeline # Return the trained pipeline
    }

def generate_visuals(pipeline, X_test, y_test, problem_type, model_name, output_dir):
    """Generates and saves relevant plots for the best model."""
    console.print(f"🎨 [bold]Generating visuals for {model_name}...[/bold]")
    plt.style.use('seaborn-v0_8-whitegrid')

    if problem_type == 'classification':
        # Confusion Matrix
        try:
            fig, ax = plt.subplots(figsize=(8, 6))
            ConfusionMatrixDisplay.from_estimator(pipeline, X_test, y_test, ax=ax, cmap='Blues', colorbar=False)
            ax.set_title(f'Confusion Matrix: {model_name}')
            plt.tight_layout()
            cm_path = output_dir / f"confusion_matrix_{model_name}.png"
            plt.savefig(cm_path)
            plt.close()
            console.print(f"  ✅ Confusion Matrix saved to [cyan]{cm_path}[/cyan]")
        except Exception as e:
            console.print(f"  ⚠️ Could not generate Confusion Matrix: {e}")

        # ROC Curve
        try:
            if hasattr(pipeline.named_steps['model'], "predict_proba"):
                fig, ax = plt.subplots(figsize=(8, 6))
                RocCurveDisplay.from_estimator(pipeline, X_test, y_test, ax=ax)
                ax.set_title(f'ROC Curve: {model_name}')
                plt.tight_layout()
                roc_path = output_dir / f"roc_curve_{model_name}.png"
                plt.savefig(roc_path)
                plt.close()
                console.print(f"  ✅ ROC Curve saved to [cyan]{roc_path}[/cyan]")
        except Exception as e:
            console.print(f"  ⚠️ Could not generate ROC Curve (possibly not a binary problem or model lacks predict_proba): {e}")

    else: # Regression
        y_pred = pipeline.predict(X_test)

        # Predicted vs. Actual Plot
        try:
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.scatter(y_test, y_pred, alpha=0.6, edgecolors='k')
            ax.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
            ax.set_xlabel('Actual Values')
            ax.set_ylabel('Predicted Values')
            ax.set_title(f'Predicted vs. Actual: {model_name}')
            plt.tight_layout()
            pvsa_path = output_dir / f"predicted_vs_actual_{model_name}.png"
            plt.savefig(pvsa_path)
            plt.close()
            console.print(f"  ✅ Predicted vs. Actual plot saved to [cyan]{pvsa_path}[/cyan]")
        except Exception as e:
            console.print(f"  ⚠️ Could not generate Predicted vs. Actual plot: {e}")

        # Residuals Plot
        try:
            residuals = y_test - y_pred
            fig, ax = plt.subplots(figsize=(8, 6))
            sns.residplot(x=y_pred, y=residuals, lowess=True, scatter_kws={'alpha': 0.5}, line_kws={'color': 'red', 'lw': 2}, ax=ax)
            ax.set_xlabel('Predicted Values')
            ax.set_ylabel('Residuals')
            ax.set_title(f'Residuals Plot: {model_name}')
            plt.tight_layout()
            res_path = output_dir / f"residuals_{model_name}.png"
            plt.savefig(res_path)
            plt.close()
            console.print(f"  ✅ Residuals plot saved to [cyan]{res_path}[/cyan]")
        except Exception as e:
            console.print(f"  ⚠️ Could not generate Residuals plot: {e}")


def generate_shap_plot(pipeline, X_train, X_test, problem_type, model_name, output_dir):
    """Generates and saves a SHAP summary plot for any model."""
    console.print(f"🤔 [bold]Generating SHAP interpretability plot for {model_name}...[/bold]")
    try:
        model = pipeline.named_steps['model']
        preprocessor = pipeline.named_steps['preprocessor']

        # Transform data and get feature names
        X_test_transformed = preprocessor.transform(X_test)

        try:
            # Works for ColumnTransformer with OneHotEncoder
            ohe_feature_names = preprocessor.named_transformers_['cat'].named_steps['onehot'].get_feature_names_out(
                X.select_dtypes(include=['object', 'category', 'bool']).columns
            )
            all_feature_names = X.select_dtypes(include=np.number).columns.tolist() + list(ohe_feature_names)
            X_test_transformed_df = pd.DataFrame(X_test_transformed, columns=all_feature_names)
        except Exception:
             # Fallback if feature names can't be extracted
            all_feature_names = None
            X_test_transformed_df = pd.DataFrame(X_test_transformed)


        # For complex models like Stacking, SHAP works best with a prediction function
        if problem_type == 'classification' and hasattr(model, 'predict_proba'):
            predict_fn = lambda x: pipeline.predict_proba(pd.DataFrame(x, columns=X_test.columns))
        else:
            predict_fn = lambda x: pipeline.predict(pd.DataFrame(x, columns=X_test.columns))

        # Use the appropriate explainer
        if isinstance(model, (DecisionTreeClassifier, DecisionTreeRegressor, RandomForestClassifier, RandomForestRegressor,
                              GradientBoostingClassifier, GradientBoostingRegressor, XGBClassifier, XGBRegressor)):
             explainer = shap.TreeExplainer(model, data=preprocessor.transform(X_train), feature_perturbation="interventional")
        else:
             # KernelExplainer is a model-agnostic fallback, requires a function and background data
             explainer = shap.KernelExplainer(predict_fn, shap.sample(X_train, 50))

        shap_values = explainer(X_test_transformed_df)

        # For classifiers with predict_proba, shap_values can be a list of arrays (one per class)
        if isinstance(shap_values, list):
             shap_values_to_plot = shap_values[1] # Plot for the positive class
        else:
             shap_values_to_plot = shap_values

        plt.figure(figsize=(10, 8))
        shap.summary_plot(shap_values_to_plot, X_test_transformed_df, show=False, plot_type="bar")
        plt.title(f"SHAP Feature Importance: {model_name}")
        plt.tight_layout()
        
        shap_filename = output_dir / f"shap_summary_{model_name}.png"
        plt.savefig(shap_filename)
        plt.close()
        console.print(f"  ✅ SHAP summary plot saved to [cyan]'{shap_filename}'[/cyan]")

    except Exception as e:
        console.print(f"  [bold yellow]⚠️ Warning: Could not generate SHAP plot. Reason: {e}[/bold yellow]")


def main(args, save_artifacts=False):
    """Main function to run the enhanced ML pipeline."""
    # --- 1. Setup & Introduction ---
    start_run_time = time.time()
    if save_artifacts:
        output_dir = Path(args.output_dir) / f"results_{time.strftime('%Y%m%d_%H%M%S')}"
        output_dir.mkdir(parents=True, exist_ok=True)

        console.print(Panel("🧠 [bold magenta]Universal ML Model Explorer Pro[/bold magenta] is Starting!", title="🚀 Launching", border_style="green"))
        console.print(f"📂 All artifacts will be saved in: [cyan]{output_dir}[/cyan]")

    # --- 2. Dataset Loading ---
    try:
        df = pd.read_csv(args.dataset_path)
    except Exception as e:
        console.print(f"[bold red]❌ Error loading dataset: {e}[/bold red]")
        return

    if args.target_column not in df.columns:
        console.print(f"[bold red]❌ Error: Target column '{args.target_column}' not found.[/bold red]")
        return

    df = df.dropna(subset=[args.target_column]) # Drop rows where target is NaN
    console.print(f"✅ Dataset loaded successfully. Shape: {df.shape}")

    # --- 3. Data Preparation & Problem Detection ---
    X = df.drop(args.target_column, axis=1)
    y = df[args.target_column]

    problem_type = detect_problem_type(y)
    console.print(Panel(f"🤖 [bold]Detected Problem Type: [cyan]{problem_type.capitalize()}[/cyan][/bold]", title="🔍 Analysis", border_style="cyan"))

    if problem_type == 'classification':
        le = LabelEncoder()
        y = pd.Series(le.fit_transform(y), name=y.name)
        console.print(f"🏷️ Target variable encoded. Classes: {list(le.classes_)}")

    # --- 4. Preprocessing & Feature Engineering ---
    preprocessor = build_preprocessor(X, problem_type, args.pca_components)

    # The full pipeline will now include feature selection after preprocessing
    # We define the model step later

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y if problem_type == 'classification' else None)

    # --- 5. Parallel Model Training ---
    models = get_models(problem_type)

    progress = Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.0f}%",
        TimeElapsedColumn(),
        console=console,
    )

    with progress:
        console.print("\n[bold green]🏋️ Training all models in parallel... Please wait![/bold green]\n")

        results = Parallel(n_jobs=-1)(
            delayed(train_and_evaluate_model)(
                name, model, preprocessor, X_train, y_train, X_test, y_test, problem_type
            )
            for name, model in models.items()
        )


    # --- 6. Model Comparison & Best Model Selection ---
    metric1_name = "Accuracy" if problem_type == 'classification' else "R-squared"
    metric2_name = "F1-Score" if problem_type == 'classification' else "RMSE"
    sort_key, reverse_sort = ("Metric1", True) if problem_type == 'classification' else ("Metric1", True)

    results.sort(key=lambda x: x[sort_key], reverse=reverse_sort)
    best_model_result = results[0]
    best_model_name = best_model_result["Model"]
    best_pipeline = best_model_result["pipeline"]

    # Display results table
    table = Table(title=f"📊 [bold]Model Performance Comparison ({problem_type.capitalize()})[/bold]")
    table.add_column("Rank", style="blue")
    table.add_column("Model", style="cyan")
    table.add_column(metric1_name, style="green")
    table.add_column(metric2_name, style="magenta")
    table.add_column("Time (s)", justify="right", style="yellow")

    for i, res in enumerate(results):
        is_best = "👑 " if i == 0 else ""
        table.add_row(f"{i+1}", f"{is_best}{res['Model']}", f"{res['Metric1']:.4f}", f"{res['Metric2']:.4f}", f"{res['Time (s)']:.2f}")

    console.print(table)
    console.print(f"🏆 [bold green]Best Model Identified: {best_model_name}[/bold green]")

    # --- 7. Generate and Save Artifacts ---
    if save_artifacts:
        console.print("\n[bold blue]--- 💾 Generating Final Artifacts ---[/bold blue]")

        # a) Save best model
        model_filename = output_dir / "best_model.pkl"
        joblib.dump(best_pipeline, model_filename)
        console.print(f"✅ Best model saved as [cyan]'{model_filename}'[/cyan]")

        # b) Generate visuals for the best model
        generate_visuals(best_pipeline, X_test, y_test, problem_type, best_model_name, output_dir)

    # c) Generate SHAP plot for the best model
    if not args.no_shap and save_artifacts:
        generate_shap_plot(best_pipeline, X_train, X_test, problem_type, best_model_name, output_dir)

    # d) Save full report
    if save_artifacts:
        report_filename = output_dir / "model_report.txt"
        with open(report_filename, "w") as f:
            f.write(f"--- Universal ML Model Explorer Report ---\n\n")
            f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Dataset: {args.dataset_path}\n")
            f.write(f"Target Variable: {args.target_column}\n")
            f.write(f"Problem Type: {problem_type.capitalize()}\n\n")
            f.write(f"--- Best Model: {best_model_name} ---\n")
            f.write(f"  - {metric1_name}: {best_model_result['Metric1']:.4f}\n")
            f.write(f"  - {metric2_name}: {best_model_result['Metric2']:.4f}\n")
            f.write(f"  - Training Time (s): {best_model_result['Time (s)']:.2f}\n\n")
            f.write("--- Full Model Comparison ---\n")
            header = f"{'Rank':<5} {'Model':<25} {metric1_name:<15} {metric2_name:<15} {'Time (s)':<10}\n"
            f.write(header + "-"*len(header) + "\n")
            for i, res in enumerate(results):
                f.write(f"{i+1:<5} {res['Model']:<25} {res['Metric1']:<15.4f} {res['Metric2']:<15.4f} {res['Time (s)']:.2f}\n")
        console.print(f"📋 Full report saved to [cyan]'{report_filename}'[/cyan]")

    # --- 8. Conclusion ---
    total_runtime = time.time() - start_run_time
    console.print(Panel(f"✅ [bold green]Pipeline finished successfully in {total_runtime:.2f} seconds![/bold green]", title="🏁 Complete", border_style="green"))

def run_pipeline_in_notebook(dataset_path: str, target_column: str, save_artifacts: bool = False, **kwargs):
    """
    A helper to run the pipeline from a Jupyter Notebook or another script.

    Args:
        dataset_path (str): Path to the dataset.
        target_column (str): Name of the target column.
        save_artifacts (bool): Whether to save models, plots, reports.
        **kwargs: Additional arguments like pca_components, no_shap, etc.
    """
    class Args:
        def __init__(self, dataset_path, target_column, save_artifacts, **kwargs):
            self.dataset_path = dataset_path
            self.target_column = target_column
            self.pca_components = kwargs.get("pca_components", None)
            self.no_shap = kwargs.get("no_shap", False)
            self.output_dir = kwargs.get("output_dir", "results") if save_artifacts else None

    args = Args(dataset_path, target_column, save_artifacts, **kwargs)
    main(args, save_artifacts)

